To build the file:
go to folder 'build'
Delethe everything in the folder
Open terminal
cmake ..
make
