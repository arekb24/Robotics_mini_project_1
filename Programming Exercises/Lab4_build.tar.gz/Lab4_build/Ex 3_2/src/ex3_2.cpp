#include <iostream>
#include <math.h>
#include <rw/math.hpp>

// Write code to convert a 3x3 rotation matrix into RPY. Use equation 3.10 and 3.11 and remember to pay
// attention to the special cases where |r31|=1

rw::math::RPY<double> rotMat2RPY(const rw::math::Rotation3D<double>& R) {
    double thx{0}, thy{0}, thz{0};
    // Check if r31 is valid
    double r31 = std::fabs(R(2,0));
    double epsilon = 1e-9;
    std::cout << R(2,0) << std::endl;
    if(std::fabs(r31 - 1) < epsilon) {
      // Invalid, return default RPY
      // When |r31| is 1 the rotation about the Y axis is 90° degrees which is a Gimbal lock situation
      // in which the equations are singular. In this case r11, r21, r32 and r33 are all zero
      std::cout << "|r31| == 1 " << std::endl;
      return rw::math::RPY<double>();
    }

    // Standard case
    thy = std::asin(-R(2,0));
    double cy = std::cos(thy);
    thx = std::atan2(cy*R(2,1), cy*R(2,2));
    thz = std::atan2(cy*R(1,0), cy*R(0,0));

    return rw::math::RPY<double>(thz, thy, thx);
}

int main() {
    // Generate reference rotation matrix
    auto rpyref = rw::math::RPY<double>(rw::math::Deg2Rad*45, rw::math::Deg2Rad*30, rw::math::Deg2Rad*60);
    auto R = rpyref.toRotation3D();

    std::cout << "R\n" << R.e() << std::endl;

    // Simple version
    auto rpy = rw::math::RPY<double>(R);

    // Manual version
    auto rpy2 = rotMat2RPY(R);

    std::cout << "Reference: \n" << rpyref << std::endl << std::endl;
    std::cout << "Simple version: \n" << rpy << std::endl << std::endl;
    std::cout << "Manual version: \n" << rpy2 << std::endl;

    return 0;
}
