#include <iostream>
#include <math.h>
#include <rw/math.hpp>

// Calculate the 3x3 rotation matrix given a specification of which axis to rotate around
enum class Axis {
    x,
    y,
    z,
};

rw::math::Rotation3D<double> calcRotationMatrix(Axis axis, double theta) {
    auto R = rw::math::Rotation3D<double>::identity();
    double c{std::cos(theta)}, s{std::sin(theta)};
    switch(axis) {
        case Axis::x:
            R(1,1) = R(2,2) = c;
            R(1,2) = -s;
            R(2,1) = s;
            break;
        case Axis::y:
            R(0,0) = R(2,2) = c;
            R(0,2) = s;
            R(2,0) = -s;
            break;
        case Axis::z:
            R(0,0) = R(1,1) = c;
            R(0,1) = -s;
            R(1,0) = s;
            break;
    }

    return R;
}

// Calculate the 3x3 rotation matrix given 3 parameters corresponding to the rotation around the individual axis
rw::math::Rotation3D<double> rpyToRotationMatrix(double tz, double ty, double tx) {
    double cx{std::cos(tx)}, cy{std::cos(ty)}, cz{std::cos(tz)};
    double sx{std::sin(tx)}, sy{std::sin(ty)}, sz{std::sin(tz)};

    rw::math::Rotation3D<double> R (cy*cz, sx*sy*cz - cx*sz, cx*sy*cz + sx*sz,
				    cy*sz, sx*sy*sz + cx*cz, cx*sy*sz - sx*cz,
				      -sy,            sx*cy,            cx*cy);
    return R;
}

int main() {
    auto r1 = calcRotationMatrix(Axis::z, rw::math::Pi/2);
    auto r3 = rpyToRotationMatrix(rw::math::Pi/2, 0, 0);
    auto rpy_mat = rw::math::RPY<double>(rw::math::Pi/2, 0, 0).toRotation3D();
    std::cout << r1.e() << std::endl << std::endl;
    std::cout << r3.e() << std::endl << std::endl;
    std::cout << rpy_mat.e() << std::endl;
    return 0;
}
